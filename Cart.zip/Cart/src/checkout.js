let ShoppingCart = document.getElementById("shopping-cart");
let label = document.getElementById("label");

/**
 * ! Basket to hold all the selected items
 * ! the getItem is retrieving data from the local storage
 * ! if local storage is blank, basket is an empty array
 */

let basket = JSON.parse(localStorage.getItem("info")) || [];

/**
 * !calculate total amount of selected Items
 */

let summation = () => {
  let cartIcon = document.getElementById("cartAmount");
  cartIcon.innerHTML = basket.map((n) => n.item).reduce((a, b) => a + b, 0);
};

summation();

/**
 * ! Generates the Cart Page with product cards composed of
 * ! images, title, price, buttons, & Total price
 * ? When basket is blank -> show's Cart is Empty
 */

let createCartItems = () => {
  if (basket.length !== 0) {
    return (ShoppingCart.innerHTML = basket
      .map((x) => {
        let { id, item } = x;
        let search = shopItemsData.find((n) => n.id === id) || [];
        let { img, price, name } = search;
        return `
      <div class="cart-item">
        <img width="100" src=${img} alt="" />

        <div class="details">
        
          <div class="title-price-x">
            <h4 class="title-price">
              <p>${name}</p>
              <p class="cart-item-price">$ ${price}</p>
            </h4>
            <i onclick="removeItem(${id})" class="bi bi-x-lg"></i>
          </div>

          <div class="cart-buttons">
            <div class="button">
              <i onclick="minus(${id})" class="bi bi-dash-lg"></i>
              <div id=${id} class="quantity">${item}</div>
              <i onclick="plus(${id})" class="bi bi-plus-lg"></i>
            </div>
          </div>

          <h3>$ ${item * price}</h3>
        
        </div>
      </div>
      `;
      })
      .join(""));
  } else {
    ShoppingCart.innerHTML = "";
    label.innerHTML = `
    <h2>Oh no! Cart is Empty :(</h2>
    <a href="index.html">
      <button class="HomeBtn">Back to Homepage</button>
    </a>
    `;
  }
};

createCartItems();

/*To increase selected product quantity*/ 
let plus = (id) => {
    let selectedItem = id;
    let search = basket.find((n) => n.id === selectedItem.id);

    if(search === undefined){
        basket.push({
            id: selectedItem.id,
            item: 1,
        });
    }
    else{
        search.item += 1;
    }
    createCartItems();
    change(selectedItem.id);

    localStorage.setItem("info", JSON.stringify(basket)); 

};

/*To decrease selected product quantity*/ 

let minus = (id) => {
    let selectedItem = id;
    let search = basket.find((n) => n.id === selectedItem.id);

    if(search === undefined) return;
    if(search.item === 0) return;
    else{
        search.item -= 1;
    }
    change(selectedItem.id);
    basket = basket.filter((x) => x.item !== 0); //only keep item with a quantity in basket
    createCartItems();

    localStorage.setItem("info", JSON.stringify(basket)); //store item quantity selection on local storage

};

/*Updates the number of selected product on the product card*/

let change = (id) => {
    let search = basket.find((n) => n.id === id);
    //console.log(search.item);
    document.getElementById(id).innerHTML = search.item;
    summation();
    TotalAmount();
};

let removeItem = (id) => {
    let selectedItem = id;
    //console.log(selectedItem.id);
    basket = basket.filter((n) => n.id !== selectedItem.id);
    createCartItems();
    TotalAmount();
    summation();
    localStorage.clear("info");
    //localStorage.setItem("info", JSON.stringify(basket)); 

};

/**
* !Calculates the total amount of products selected with their quantities
* ! If the basket is empty, It will not show anything
**/
let TotalAmount = () => {
    if(basket.length !==0){
        let amount = basket.map((n)=>{
            let { item, id } = n;
            let search = shopItemsData.find((n) => n.id === id) || [];
            return item * search.price;

        }).reduce((a,b) => a + b, 0);
        //console.log(amount);
        label.innerHTML = `
        <h2>Total Item : $ ${amount}</h2>
        <button onclick="checkOut()" class="checkout">Checkout</button>
        <button onclick="clearCart()" class="removeAll">Clear Cart</button>
        `;
    }
    else return
};
TotalAmount();

/*Clear the cart and remove data from local Storage*/ 
let clearCart = () => {
    basket = []
    createCartItems();
    summation();
    localStorage.setItem("info", JSON.stringify(basket)); 
    //clearCart();
};

// The checkout function
function checkOut() {
    // Get the total cost and number of items from the shopping cart
    const totalCost = basket
      .map((x) => {
        let search = shopItemsData.find((n) => n.id === x.id);
        return search ? search.price * x.item : 0;
      })
      .reduce((a, b) => a + b, 0);
    const totalItems = basket.map((x) => x.item).reduce((a, b) => a + b, 0);

    alert(`Your Total item : ${totalItems}\n Your Total Amount: ${totalCost}`);
}

window.addEventListener("beforeunload", (event) => {
    // Remove the data saved under the key "info" in localStorage
    localStorage.removeItem("info");
  });
