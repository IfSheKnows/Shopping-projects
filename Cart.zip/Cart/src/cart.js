let shop = document.getElementById('shop');


let basket = JSON.parse(localStorage.getItem("info")) || [];

//console.log(shop);

let generateShop = () => {
    return (shop.innerHTML = shopItemsData
        .map((n) => {
            let { id, name, price, desc, img } = n;
            let search = basket.find((n) => n.id === id) || [];
            return `
        <div id=product-id-${id} class="item">
            <img width="220" src=${img} alt="">
            <div class="details">
                <h3>${name}</h3>
                <p>${desc}</p>
                <div class="price-quantity">
                    <h2>$ ${price}</h2>
                    <div class="button">
                      <i onclick="minus(${id})"class="bi bi-dash-lg"></i>
                      <div id=${id} class="quantity">
                      ${search.item == undefined? 0: search.item}
                      </div>
                      <i onclick="plus(${id})" class="bi bi-plus-lg"></i>
                    </div>
                </div>
            </div>
        </div>`
    }).join(""));
};

generateShop();


let plus = (id) => {
    let selectedItem = id;
    let search = basket.find((n) => n.id === selectedItem.id);

    if(search === undefined){
        basket.push({
            id: selectedItem.id,
            item: 1,
        });
    }
    else{
        search.item += 1;
    }
    //console.log(basket);
    change(selectedItem.id);

    localStorage.setItem("info", JSON.stringify(basket)); 

};
let minus = (id) => {
    let selectedItem = id;
    let search = basket.find((n) => n.id === selectedItem.id);

    if(search === undefined) return;
    if(search.item === 0) return;
    else{
        search.item -= 1;
    }
    //console.log(basket);
    change(selectedItem.id);
    basket = basket.filter((x) => x.item !== 0); //only keep item with a quantity in basket

    localStorage.setItem("info", JSON.stringify(basket)); //store item quantity selection on local storage

};
let change = (id) => {
    let search = basket.find((n) => n.id === id);
    //console.log(search.item);
    document.getElementById(id).innerHTML = search.item;
    summation();
};
//Summation function updates the cart quantity as the items are added
let summation = () => {
    let cartIcon = document.getElementById("cartAmount");
    cartIcon.innerHTML = basket.map((n) => n.item).reduce((a,b) => a+b,0);
    console.log(basket);
};

summation();