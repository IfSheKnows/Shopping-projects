#
#
#Author: Ifeoluwani Jacob
#Final Project Checks your password's health
#
#

import string

class passHealth():
    def __init__(self, password):
        self.password = password

    def Prompt(self):
        print("\nA strong password consist of: \n~UPPERCASE and lowercase letters \n~Any special characters e.g(!@#$%><?) \n~Digits from 0 - 9,  \n~Total Length is 13 or more\n")

#Checking requirements for passwords to be considered weak, medium, or strong
    def Checker(self):
        if all(char in string.ascii_letters or string.digits and len(self.password) < 8 for char in self.password):
            print(self.password + " => Weak Password, do better: ")

        elif all(char in string.ascii_letters and string.digits or string.punctuation and len(self.password) <= 13 for char in self.password):
            print(self.password + " => Medium strength, you can do better than that")

        elif all(char in string.ascii_letters or string.digits and string.punctuation and len(self.password) > 13 for char in self.password):
            print(self.password + " => Strong Password, the genius you are!")
        else:
            ("Password is not good enough")

#passLength inheriting attributes of sub class to check for length requirement
class passLength(passHealth):
    def __init__(self, password):
        passHealth.__init__(self, password)

    def CheckerLen(self):
        if len(self.password) <= 8:
            return " too short :( "
        elif len(self.password) >  8 and len(self.password)<= 13:
            return "Not recommended length"
        else:
            return "Sufficient length ;)"

#const shift key for encryption
shift = 4
