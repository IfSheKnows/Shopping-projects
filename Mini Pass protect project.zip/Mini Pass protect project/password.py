#
#
# Author: Ifeoluwani Jacob
# This file will import the module passcheck with the classes and implement
# password security
#
import passcheck
import string
import csv

csv_file = 'data.csv'

# Output as standard to determine password strength
with open('pass_strength.txt', 'w') as output_file:
 
    # Open the CSV file
    with open(csv_file) as file:
        File = csv.DictReader(file)

        # Iterate through the rows in the CSV file
        for i in File:
            # Check the strength of the password
            # Pattern that is used in the data set to determine password strength
            if all(char in string.ascii_letters + string.digits for char in i["password"]) and len(i["password"]) < 8:
                # Write the password and its strength to the text file
                output_file.write(i["password"] + " Weak pass, strength: " + i["strength"] + "\n")
            elif all(char in string.ascii_letters + string.digits + string.punctuation for char in i["password"]) and len(i["password"]) <= 13:
                output_file.write(i["password"] + " Medium pass, strength: " + i["strength"] + "\n")
            elif all(char in string.ascii_letters + string.digits + string.punctuation for char in i["password"]) and len(i["password"]) > 13:
                output_file.write(i["password"] + " Strong pass, strength: " + i["strength"] + "\n")


#Input your password
passwrd = input("Create a password: ")

pass_health = passcheck.passHealth(passwrd)
pass_health.Checker()
pass_health.Prompt()

pass_length = passcheck.passLength(passwrd)
len_status = pass_length.CheckerLen()
print(f"Password length status: {len_status}")


encryption = input("\nWould you like to secure your password? (Yes/No)")

#if user permits for their password to be secured
if encryption == 'Yes':
    #initialize the empty string to store encrypted password
    encrypt_pass = ""
    
    #initialize the empty stack
    stack = []
    
#push each letter user makes into the stack
    for char in passwrd:
        stack.append(char)
#shift each letter by the shift value and add to encrypted string
#pop each one of them from stack
    while len(stack) > 0:
        char = stack.pop(0)
        shifted_char = chr((ord(char) + passcheck.shift) % 26 + ord(passwrd[3]))
        encrypt_pass += shifted_char
    print("Your pasword has been secured! Thank you.")
    
#Commenting the line below so user does not view encrypted password
#For this assigment it can be uncommented and then ran to test functionality
    
    #print("Your password has been secured:", encrypt_pass)
    
#If the user does not wnat to secure their pass
else:
    print("Your password has been created but it is not secured. Thank you.")
